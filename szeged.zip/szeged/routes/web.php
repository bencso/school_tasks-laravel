<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\JaratController;
use App\Http\Controllers\MegalloController;

Route::get('/', [JaratController::class, 'welcome']);

Route::get("/jaratok", [JaratController::class, 'index']);

Route::get("/jarat/{id}", [JaratController::class, 'jarat']);

Route::get("/megallo/{id}", [JaratController::class, 'megallo']);

Route::get("/kereses", [JaratController::class, 'kereses']);
