@extends('layout')
@section('content')
    <h1 class="text-center mt-3 display-4">{{ $megallo->nev }}</h1>
    <div class="d-flex flex-column gap-3 my-4 flex-wrap justify-content-center">
        <p class="text-center display-6">Járatok:</p>
        <div class="d-flex gap-3 flex-wrap justify-content-center">
            @foreach ($jaratok as $jarat)
                <a class="line-number" style="background-color: {{ $jarat->hatterszin }};"
                    href="/jarat/{{ $jarat->jaratok_id }}">
                    <span style="color: {{ $jarat->betuszin }}">{{ $jarat->jaratok_id }}</span>
                </a>
            @endforeach
        </div>
    </div>
@endsection
