@extends('layout')
@section('content')
    <h1 class="text-center display-6 py-3">Szeged</h1>
    <p class="line-p fs-5">
        @foreach ($jaratok as $jarat)
            <a class="line-number" style="background-color: {{ $jarat->hatterszin }};"
                href="/jarat/{{ $jarat->jaratok_id }}"><span
                    style="color: {{ $jarat->betuszin }}">{{ $jarat->jaratok_id }}</span></a>
        @endforeach
    </p>
    <p>
        <img src="/img/map_of_szeged.png" alt="Szeged térképe" class="img-fluid">
    </p>
@endsection
