@extends('layout')

@section('content')
    <div class="row d-flex justify-content-center align-items-center my-4">
        <div class="col-md-8">
            <div class="search">
                <i class="fa fa-search"></i>
                <form action="/kereses" method="get">
                    <input name="s" type="text" class="form-control" placeholder="Lorem ipsum dolor sit amet">
                    <button class="btn btn-dark">Keresés</button>
                </form>
            </div>
            @error('sv')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
        </div>
        @isset($jaratok)
            <h5>Keresés eredménye</h5>
            @foreach ($jaratok as $item)
                <div class="col-md-8">
                    <p>{{ $item->nev }}</p>
            @endforeach
        @endisset
    </div>
@endsection
