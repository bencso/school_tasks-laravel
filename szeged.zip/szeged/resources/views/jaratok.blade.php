@extends('layout')

@section('content')
    @foreach ($jaratok as $jaratTipus => $jaratok)
        <h4 class="mt-4">{{ ucfirst($jaratTipus) }}</h4>
        <table class="table table-bordered">
            <thead class="bg-dark text-white">
                <tr>
                    <th class="text-center" style="width: 10%">Járatszám</th>
                    <th>Útvonal</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($jaratok as $jarat)
                    <tr>
                        <td class="text-center"><a href="/jarat/{{ $jarat->jaratok_id }}">{{ $jarat->jaratszam }}</a></td>
                        <td>{{ $jarat->jarat_leiras }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endforeach
@endsection
