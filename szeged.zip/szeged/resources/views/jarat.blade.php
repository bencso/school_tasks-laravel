@extends('layout')
@section('content')
    <div class="d-flex gap-3 my-3 flex-wrap">
        <div class="line-number" style="background-color: {{ $jarat->hatterszin }};" href="/jarat/{{ $jarat->jaratok_id }}">
            <span style="color: {{ $jarat->betuszin }}">{{ $jarat->jaratok_id }}</span>
        </div>
        <p style="align-content: center; margin: 0;">
            {{ $jarat->jarat_leiras }}
        </p>
    </div>

    <div class="row">
        <div class="col-12 col-md-6 mb-3">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th colspan="2">Megállók oda</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($utvonalOda as $test)
                        <tr>
                            <td style="width: 10%" class="text-center">{{ $loop->iteration }}</td>
                            <td><a href="/megallo/{{ $test->megallo_id }}">{{ $test->nev }}</a></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="col-12 col-md-6 mb-3">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th colspan="2">Megállók vissza</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($utvonalVissza as $test)
                        <tr>
                            <td style="width: 10%" class="text-center">{{ $loop->iteration }}</td>
                            <td><a href="/megallo/{{ $test->megallo_id }}">{{ $test->nev }}</a></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
