<?php $__env->startSection('content'); ?>
    <h1 class="text-center display-6 py-3">Szeged</h1>
    <p class="line-p fs-5">
        <?php $__currentLoopData = $jaratok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="line-number" style="background-color: <?php echo e($jarat->hatterszin); ?>;"
                href="/jarat/<?php echo e($jarat->jaratok_id); ?>"><span
                    style="color: <?php echo e($jarat->betuszin); ?>"><?php echo e($jarat->jaratok_id); ?></span></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </p>
    <p>
        <img src="/img/map_of_szeged.png" alt="Szeged térképe" class="img-fluid">
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\03_Szeged\szeged\resources\views/welcome.blade.php ENDPATH**/ ?>