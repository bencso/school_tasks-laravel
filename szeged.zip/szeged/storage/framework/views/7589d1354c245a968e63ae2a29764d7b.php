<?php $__env->startSection('content'); ?>
    <div class="d-flex gap-3 my-3 flex-wrap">
        <div class="line-number" style="background-color: <?php echo e($jarat->hatterszin); ?>;" href="/jarat/<?php echo e($jarat->jaratok_id); ?>">
            <span style="color: <?php echo e($jarat->betuszin); ?>"><?php echo e($jarat->jaratok_id); ?></span>
        </div>
        <p style="align-content: center; margin: 0;">
            <?php echo e($jarat->jarat_leiras); ?>

        </p>
    </div>

    <div class="row">
        <div class="col-12 col-md-6 mb-3">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th colspan="2">Megállók oda</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $utvonalOda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 10%" class="text-center"><?php echo e($loop->iteration); ?></td>
                            <td><a href="/megallo/<?php echo e($test->megallo_id); ?>"><?php echo e($test->nev); ?></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col-12 col-md-6 mb-3">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th colspan="2">Megállók vissza</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $utvonalVissza; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 10%" class="text-center"><?php echo e($loop->iteration); ?></td>
                            <td><a href="/megallo/<?php echo e($test->megallo_id); ?>"><?php echo e($test->nev); ?></a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\03_Szeged\szeged\resources\views/jarat.blade.php ENDPATH**/ ?>