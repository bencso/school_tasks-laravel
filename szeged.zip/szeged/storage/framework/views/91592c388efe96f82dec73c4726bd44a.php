<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center align-items-center my-4">
        <div class="col-md-8">
            <div class="search">
                <i class="fa fa-search"></i>
                <form action="/kereses" method="get">
                    <input name="s" type="text" class="form-control" placeholder="Lorem ipsum dolor sit amet">
                    <button class="btn btn-dark">Keresés</button>
                </form>
            </div>
            <?php $__errorArgs = ['sv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if(isset($jaratok)): ?>
            <h5>Keresés eredménye</h5>
            <?php $__currentLoopData = $jaratok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-8">
                    <p><?php echo e($item->nev); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\03_Szeged\szeged\resources\views/kereses.blade.php ENDPATH**/ ?>