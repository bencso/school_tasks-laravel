<?php $__env->startSection('content'); ?>
    <h1 class="text-center mt-3 display-4"><?php echo e($megallo->nev); ?></h1>
    <div class="d-flex flex-column gap-3 my-4 flex-wrap justify-content-center">
        <p class="text-center display-6">Járatok:</p>
        <div class="d-flex gap-3 flex-wrap justify-content-center">
            <?php $__currentLoopData = $jaratok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="line-number" style="background-color: <?php echo e($jarat->hatterszin); ?>;"
                    href="/jarat/<?php echo e($jarat->jaratok_id); ?>">
                    <span style="color: <?php echo e($jarat->betuszin); ?>"><?php echo e($jarat->jaratok_id); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\03_Szeged\szeged\resources\views/megallo.blade.php ENDPATH**/ ?>