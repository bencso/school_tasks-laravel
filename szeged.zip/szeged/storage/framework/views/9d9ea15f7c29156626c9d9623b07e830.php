<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $jaratok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jaratTipus => $jaratok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h4 class="mt-4"><?php echo e(ucfirst($jaratTipus)); ?></h4>
        <table class="table table-bordered">
            <thead class="bg-dark text-white">
                <tr>
                    <th class="text-center" style="width: 10%">Járatszám</th>
                    <th>Útvonal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $jaratok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jarat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><a href="/jarat/<?php echo e($jarat->jaratok_id); ?>"><?php echo e($jarat->jaratszam); ?></a></td>
                        <td><?php echo e($jarat->jarat_leiras); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\03_Szeged\szeged\resources\views/jaratok.blade.php ENDPATH**/ ?>