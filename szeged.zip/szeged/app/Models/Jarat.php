<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\Megallo;
use App\Models\Utvonal;

class Jarat extends Model
{
    use HasFactory;
    protected $table = "jaratok";
    public $timestamps = false;
    public $primaryKey = "jaratok_id";

    public function utvonal()
    {
        return $this->hasMany(Utvonal::class, 'jaratok_id', 'jaratok_id');
    }

    public function getTrams()
    {
        return $this->where('jarat_tipus', 1)->get();
    }

    public function getTrains()
    {
        return $this->where('jarat_tipus', 2)->get();
    }

    public function getTrolleys()
    {
        return $this->where('jarat_tipus', 3)->get();
    }


    public function getJarat($id)
    {
        return $this->where('jaratok_id', $id)->first();
    }

    public function getMegallo($id)
    {
        return Megallo::find($id)->megalloNeve($id);
    }

    public function getJaratok($id)
    {
        $utvonalok = Megallo::find($id)->jaratok($id);
        $jaratok = [];
        foreach ($utvonalok as $utvonal) {
            $jaratok[] = $this->where('jaratok_id', $utvonal->jaratok_id)->first();
        }
        return collect($jaratok)->unique('jaratok_id')->values();
    }

    public function getJaratUtvonalOda($id)
    {
        $megallok = $this->where('jaratok_id', $id)->first()->utvonal()->where('utirany', "o")->get();
        $oda = [];
        foreach ($megallok as $megallo) {
            $oda[] = Megallo::find($megallo->megallo_id);
        }
        return $oda;
    }

    public function getJaratUtvonalVissza($id)
    {
        $megallok = $this->where('jaratok_id', $id)->first()->utvonal()->where('utirany', "v")->get();
        $vissza = [];
        foreach ($megallok as $megallo) {
            $vissza[] = Megallo::find($megallo->megallo_id);
        }
        return $vissza;
    }
}
