<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Megallo extends Model
{
    use HasFactory;
    protected $table = "megallo";
    public $timestamps = false;
    public $primaryKey = "megallo_id";

    public function megalloNeve($id)
    {
        return $this->where('megallo_id', $id)->first();
    }

    public function utvonal()
    {
        return $this->hasMany(Utvonal::class, 'megallo_id', 'megallo_id');
    }

    public function jaratok($id)
    {
        return $this->where('megallo_id', $id)->first()->utvonal()->get();
    }

    public function kereses($kereses)
    {
        return $this->where('nev', 'like', "%$kereses%")->get();
    }
}
