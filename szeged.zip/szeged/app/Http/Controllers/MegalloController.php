<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Megallo;

class MegalloController extends Controller
{

}
