<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Utvonal;

class UtvonalController extends Controller
{
    //
}
