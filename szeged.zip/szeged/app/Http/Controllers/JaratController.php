<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jarat;
use App\Models\Megallo;

class JaratController extends Controller
{
    function welcome()
    {
        return view('welcome', ["jaratok" => Jarat::all()]);

    }
    function index()
    {
        $jarat = new Jarat();

        return view(
            'jaratok',
            [
                'jaratok' => [
                    'tram' => $jarat->getTrams(),
                    'villamos' => $jarat->getTrains(),
                    'troli' => $jarat->getTrolleys()
                ]
            ]
        );
    }

    function jarat($id)
    {
        $jarat = new Jarat();
        return view('jarat', ['jarat' => $jarat->getJarat($id), "utvonalOda" => $jarat->getJaratUtvonalOda($id), "utvonalVissza" => $jarat->getJaratUtvonalVissza($id)]);
    }

    function kereses()
    {
        $s = Request()->query(key: "s");
        if (is_null($s)) {
            $uri = Request()->getRequestUri();
            if ($uri == "/kereses") {
                return view("kereses");
            } else {
                return redirect("/kereses")->withErrors(["sv" => "A keresési feltétel nem lehet üres!"]);
            }
        } elseif (strlen($s) < 4) {
            return redirect("/kereses")->withErrors(["sv" => "A keresési feltételnek legalább 4 karakter hosszúnak kell lennie!"]);
        } else {
            return view('kereses', [
                'jaratok' => Megallo::where('nev', 'like', "%$s%")->get(),
                'error' => null
            ])->withErrors(["sv" => ""]);
        }
    }
}
