@extends('layout')
@section('content')
    <h1 class="my-3 text-center">Keresés</h1>
    <div class="container my-5">
        <form action="/kereses" method="post" class="mydiv1 mx-auto">
            @csrf
            <div class="d-flex row gap-2 justify-content-center">
                <label for="search">Keresés</label>
                <div class="d-flex gap-2">
                    <input type="text" class="form-control" id="search" name="search">
                    <button type="submit" class="btn btn-dark mydiv3 h">Keresés</button>
                </div>
                @error('search')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </form>

        <div class="mydiv1 mx-auto">
            @isset($results)
                <hr class="container">
                <h2>Keresési eredmények</h2>

                @if (count($results) == 0)
                    <div>Nincs találat, próbálj más kulcsszót</div>
                @endif

                <ul class="list-unstyled">
                    @foreach ($results as $result)
                        <li class="my-3">
                            <a href="/etel/{{ $result->etelid }}">{{ $result->nev }}</a>
                        </li>
                    @endforeach
                </ul>
            @endisset
        </div>
    @endsection
