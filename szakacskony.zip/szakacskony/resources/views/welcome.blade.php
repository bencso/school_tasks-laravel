@extends('layout')
@section('content')
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 mt-4">
        @foreach ($etelek as $etel)
            <div class="col mt-3">
                <div class="card h-100">
                    <img src="/img/category-{{ $etel['kep'] }}" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">{{ $etel['category'] }}</h5>
                        <ul class="list-unstyled">
                            @foreach ($etel['etelek'] as $reszek)
                                <li>
                                    <a href="/etel/{{ $reszek->etelid }}">{{ $reszek->nev }}</a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
@endsection
