@extends('layout')
@section('content')
    <h1 class="my-3 text-center">{{ $etel['nev'] }}</h1>
    <div class="row">
        <div class="col-md">
            <img src="/img/{{ $etel['id'] }}.jpg" alt="{{ $etel['nev'] }}" class="img-fluid">
        </div>
        <div class="col-md mt-3">
            <p>Hozzávalók:</p>
            <ul>
                @foreach ($etel['hozzavalok'] as $hozzavalo)
                    <li>{{ $hozzavalo['mennyiseg'] }} {{ $hozzavalo['nev'] }}</li>
                @endforeach
            </ul>
            <p>Elkészítési idő: {{ $etel['ido'] }} perc</p>
            <p>Elkészítés: {{ $etel['elkeszites'] }}</p>
        </div>
    </div>
@endsection
