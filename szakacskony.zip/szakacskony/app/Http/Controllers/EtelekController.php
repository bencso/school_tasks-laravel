<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Alapanyag;
use App\Models\Etelek;
use App\Models\Hozzavalo;
use Illuminate\Support\Facades\DB;

class EtelekController extends Controller
{
    public function index()
    {
        $etelek = DB::table('etelek')
            ->orderBy('nev')
            ->get()
            ->groupBy('besorolas')
            ->toArray();

        $etelek = array_map(function ($etelek) {
            $category = '';
            switch ($etelek[0]->besorolas) {
                case "l":
                    $category = 'Levesek';
                    $kep = "soup.jpg";
                    break;
                case "f":
                    $category = 'Főételek';
                    $kep = "stew.jpg";
                    break;
                case "é":
                    $category = 'Édességek';
                    $kep = "dessert.jpg";
                    break;
                case "k":
                    $category = 'Készételek';
                    $kep = "meal.jpg";
                    break;
            }
            return ['category' => $category, 'etelek' => $etelek, 'kep' => $kep];
        }, $etelek);

        $etelek = array_values($etelek);

        return view('welcome', compact('etelek'));
    }

    public function show($id)
    {
        $etel = [
            'id' => $id,
            'nev' => Etelek::find($id)->nev,
            'hozzavalok' => Etelek::find($id)->hozzavalok()->get()->toArray(),
            "elkeszites" => Etelek::find($id)->leiras,
            "ido" => Etelek::find($id)->elkeszitesiido,
        ];
        return view('etel', compact('etel', 'id'));
    }

    public function kereses()
    {
        return view('kereses');
    }

    public function keresesPost(Request $request)
    {
        $request->validate([
            'search' => 'required|min:4'
        ], [
            'search.required' => 'Keresés mező kitöltése kötelező!',
            'search.min' => 'Legalább 4 karaktert adjon meg!'
        ]);

        $results = Etelek::where('nev', 'like', '%' . $request->search . '%')->get();

        return view('kereses', compact('results'));
    }
}
