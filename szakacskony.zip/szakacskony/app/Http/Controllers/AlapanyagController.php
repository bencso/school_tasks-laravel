<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Alapanyag;
use App\Models\Etelek;
use App\Models\Hozzavalo;

class AlapanyagController extends Controller
{
    //
}
