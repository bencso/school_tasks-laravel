<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Alapanyag extends Model
{
    protected $table = 'alapanyagok';
    protected $primaryKey = 'anyagid';
}
