<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Etelek extends Model
{
    protected $table = 'etelek';
    protected $primaryKey = 'etelid';

    public function alapanyagok()
    {
        return $this->belongsToMany(Alapanyag::class, 'hozzavalok', 'etelid', 'anyagid');
    }

    public function hozzavalok()
    {
        return $this->belongsToMany(Alapanyag::class, 'hozzavalok', 'etelid', 'anyagid')
            ->withPivot('mennyiseg', 'alapanyagok.mennyegyseg')
            ->selectRaw("nev, CONCAT(hozzavalok.mennyiseg,' ', alapanyagok.mennyegyseg) as mennyiseg");
    }
}
