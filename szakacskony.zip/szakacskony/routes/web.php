<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AlapanyagController;
use App\Http\Controllers\EtelekController;
use App\Http\Controllers\HozzavaloController;

Route::get('/', [EtelekController::class, 'index']);
Route::get('/etel', [EtelekController::class, 'etel']);
Route::get('/etel/{id}', [EtelekController::class, 'show']);
Route::get("/kereses", [EtelekController::class, 'kereses']);
Route::post("/kereses", [EtelekController::class, 'keresesPost']);
