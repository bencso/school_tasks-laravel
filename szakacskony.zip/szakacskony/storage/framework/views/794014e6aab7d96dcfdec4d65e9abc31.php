<?php $__env->startSection('content'); ?>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 mt-4">
        <?php $__currentLoopData = $etelek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col mt-3">
                <div class="card h-100">
                    <img src="/img/category-<?php echo e($etel['kep']); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($etel['category']); ?></h5>
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $etel['etelek']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reszek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="/etel/<?php echo e($reszek->etelid); ?>"><?php echo e($reszek->nev); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\04_Szakacskonyv\szakacskony\resources\views/welcome.blade.php ENDPATH**/ ?>