<?php $__env->startSection('content'); ?>
    <h1 class="my-3 text-center">Keresés</h1>
    <div class="container my-5">
        <form action="/kereses" method="post" class="mydiv1 mx-auto">
            <?php echo csrf_field(); ?>
            <div class="d-flex row gap-2 justify-content-center">
                <label for="search">Keresés</label>
                <div class="d-flex gap-2">
                    <input type="text" class="form-control" id="search" name="search">
                    <button type="submit" class="btn btn-dark mydiv3 h">Keresés</button>
                </div>
                <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </form>

        <div class="mydiv1 mx-auto">
            <?php if(isset($results)): ?>
                <hr class="container">
                <h2>Keresési eredmények</h2>

                <?php if(count($results) == 0): ?>
                    <div>Nincs találat, próbálj más kulcsszót</div>
                <?php endif; ?>

                <ul class="list-unstyled">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="my-3">
                            <a href="/etel/<?php echo e($result->etelid); ?>"><?php echo e($result->nev); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\04_Szakacskonyv\szakacskony\resources\views/kereses.blade.php ENDPATH**/ ?>