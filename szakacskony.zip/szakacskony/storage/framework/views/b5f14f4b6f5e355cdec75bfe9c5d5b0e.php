<?php $__env->startSection('content'); ?>
    <h1 class="my-3 text-center"><?php echo e($etel['nev']); ?></h1>
    <div class="row">
        <div class="col-md">
            <img src="/img/<?php echo e($etel['id']); ?>.jpg" alt="<?php echo e($etel['nev']); ?>" class="img-fluid">
        </div>
        <div class="col-md mt-3">
            <p>Hozzávalók:</p>
            <ul>
                <?php $__currentLoopData = $etel['hozzavalok']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hozzavalo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($hozzavalo['mennyiseg']); ?> <?php echo e($hozzavalo['nev']); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <p>Elkészítési idő: <?php echo e($etel['ido']); ?> perc</p>
            <p>Elkészítés: <?php echo e($etel['elkeszites']); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\babolnai.bence\Desktop\04_Szakacskonyv\szakacskony\resources\views/etel.blade.php ENDPATH**/ ?>